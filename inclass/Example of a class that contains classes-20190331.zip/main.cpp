#include <iostream>

#include "Area.h"

using namespace std;

int main()
{
    Area thing;

    cout << thing.getArea() << endl;

    return 0;
}
