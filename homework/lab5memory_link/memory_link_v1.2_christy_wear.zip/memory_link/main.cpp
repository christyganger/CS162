/*
Program written by christy wear
3/25/3019
version 1.2
cis 162C+
*/
#include "header.h"

int main()
{
    welcome();
    t_player *player_one = new t_player;
    srand(time(NULL));
    do{
    populate_demo_board(player_one);

    clear_play_field(player_one);

    //playfield

    print_play_field(player_one);

    //populate playfield
    populate_play_field(player_one);
    bool play_loop_done = false;

    do{

        get_move(player_one);

        check_if_match(player_one);
        print_play_field(player_one);

    //debug
    //player_one->debug = true;
    //print_play_field(player_one);

    play_loop_done = check_for_win(player_one);
    }while(!play_loop_done);

    }while(play_again(player_one));
    delete player_one;
    return 0;
}
