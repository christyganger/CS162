/*
Created by Christy Ganger
4/7/2019
cis 162c++
Lab 8
version 0.5
*/
#ifndef LIST_H
#define LIST_H
#include <string>
#include "Car.h"

struct Link {
    Car * this_car;
    Link * next;

};
class CarList
{
    public:
        CarList();
        CarList(std::string, std::string, int);
        virtual ~CarList();
        void addCar(std::string, std::string, int);

        void recDestruct(Link * ptr);
        bool findCar(std::string, std::string, int);
        Car* removeHead();
        std::string displayList();
    protected:

    private:
        Link *head;
    bool recfind(Link * ptr, Car * temp_car);
};

#endif // LIST_H
